-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 13, 2017 at 08:15 上午
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grouppj`
--

-- --------------------------------------------------------

--
-- Table structure for table `Comments`
--

CREATE TABLE `Comments` (
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note_id` int(11) NOT NULL,
  `comment_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Comments`
--

INSERT INTO `Comments` (`comment_id`, `user_id`, `note_id`, `comment_content`) VALUES
(15, 2, 2, 'Seem&#039;s Great'),
(16, 2, 9, 'HHH, well done'),
(17, 3, 2, 'ni zhe ge pangzi'),
(18, 3, 1, 'I love VR'),
(19, 3, 9, 'comment');

-- --------------------------------------------------------

--
-- Table structure for table `Followers`
--

CREATE TABLE `Followers` (
  `trail_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `follwer_name` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Followers`
--

INSERT INTO `Followers` (`trail_id`, `user_id`, `follwer_name`) VALUES
(37, 1, '2'),
(38, 1, '3');

-- --------------------------------------------------------

--
-- Table structure for table `Notes`
--

CREATE TABLE `Notes` (
  `note_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `article` text NOT NULL,
  `article_url` text NOT NULL,
  `note_content` text NOT NULL,
  `topic` text NOT NULL,
  `tag` text NOT NULL,
  `hot` int(11) NOT NULL,
  `ifpublicize` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Notes`
--

INSERT INTO `Notes` (`note_id`, `user_id`, `article`, `article_url`, `note_content`, `topic`, `tag`, `hot`, `ifpublicize`) VALUES
(1, 1, 'VR Juggler: a virtual platform for virtual reality application development', 'http://cn.bing.com/academic/profile?id=76ab5f8d4cc9de7f8823d9c40cac3746&encoded=0&v=paper_preview&mkt=zh-cn', 'In order to enhance operator performance and understanding within remote environments, most research and development of telepresence systems has been directed towards improving the fidelity of the link between operator and environment.\r\nToday, scientists and engineers are exploring advanced applications and uses of immersive systems that can be cost-effectively applied in their fields. However, one of the impediments to the widespread use of these technologies is the extensive technical expertise required of application developers.', 'Computer Science', 'VR', 6, 1),
(3, 1, 'Rapid object detection using a boosted cascade of simple features', 'http://cn.bing.com/academic/profile?id=d80c1a80562aa9e828cd855d7d240b04&encoded=0&v=paper_preview&mkt=zh-cn', 'This paper describes a machine learning approach for visual object detection which is capable of processing images extremely rapidly and achieving high detection rates. This work is distinguished by three key contributions.', 'Computer Science', 'ML', 1, 1),
(9, 1, 'Machine learning in automated text categorization Data', 'http://cn.bing.com/academic/profile?id=e712dad22ba49fdcc83b03f5c467ae60&encoded=0&v=paper_preview&mkt=zh-cn', 'The automated categorization (or classification) of texts into predefined categories has witnessed a booming interest in the last 10 years, due to the increased availability of documents in digital form and the ensuing need to organize them.', 'Computer Science', 'ML', 9, 1),
(10, 2, 'DnaSP v5: a software for comprehensive analysis of DNA polymorphism data', 'http://cn.bing.com/academic/profile?id=51a2068541fbbe070745fbdf1e8a8bf9&encoded=0&v=paper_preview&mkt=zh-cn', 'Motivation: DnaSP is a software package for a comprehensive analysis of DNA polymorphism data. Version 5 implements a number of new features and analytical methods allowing extensive DNA polymorphism analyses on large datasets. \r\n Among other features, the newly implemented methods allow for: (i) analyses on multiple data files; (ii) haplotype phasing; (iii) analyses on insertion/deletion polymorphism data; (iv) visualizing sliding window results integrated with available genome annotations in the UCSC browser. Availability: Freely available to academic users from:', 'Computer Science', 'Data', 1, 1),
(11, 3, 'baidu', 'www.baidu.com', 'wo ai baidu', 'Chemical', 'bai', 0, 1),
(12, 3, 'bing', 'bing.com', ' wo ai bingaaa', 'Others', 'bai', 0, 1),
(13, 3, 'what baidu', 'www.baidu.com', 'aaa', 'Others', 'bai', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Replies`
--

CREATE TABLE `Replies` (
  `reply_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `reply_content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Replies`
--

INSERT INTO `Replies` (`reply_id`, `user_id`, `comment_id`, `reply_content`) VALUES
(1, 7, 1, 'test');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `user_id` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `bio` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`user_id`, `username`, `password`, `mail`, `bio`) VALUES
(1, 'davin', 'f5bb0c8de146c67b44babbf4e6584cc0', 'davin@gmail.com', 'Admin'),
(2, 'pangzi', '0e9212587d373ca58e9bada0c15e6fe4', 'pangzi@gmail.com', 'SHuai'),
(3, 'xiaonan', '0e9212587d373ca58e9bada0c15e6fe4', 'asdf@163.com', 'wo zui qiang'),
(4, 'yudifeng', '4297f44b13955235245b2497399d7a93', '123@vc.com', 'hha');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Comments`
--
ALTER TABLE `Comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `Followers`
--
ALTER TABLE `Followers`
  ADD PRIMARY KEY (`trail_id`);

--
-- Indexes for table `Notes`
--
ALTER TABLE `Notes`
  ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `Replies`
--
ALTER TABLE `Replies`
  ADD PRIMARY KEY (`reply_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Comments`
--
ALTER TABLE `Comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `Followers`
--
ALTER TABLE `Followers`
  MODIFY `trail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `Notes`
--
ALTER TABLE `Notes`
  MODIFY `note_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `Replies`
--
ALTER TABLE `Replies`
  MODIFY `reply_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
